package com.jarvis.assistant

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import android.app.AlarmManager
import android.app.PendingIntent

class MainActivity : ComponentActivity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var apiKey: EditText
    private lateinit var connect: Button
    private var themeName = "DARK"

    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        applyTheme(prefs.getString("theme", "DARK") ?: "DARK")
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 22)
        }

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val menu = Button(this).apply {
            text = "⋮"
            textSize = 25f
            setOnClickListener { showThemeMenu() }
        }
        top.addView(menu, LinearLayout.LayoutParams(58, 58))

        val title = TextView(this).apply {
            text = "J  A  R  V  I  S"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        top.addView(title, LinearLayout.LayoutParams(0, 58, 1f))

        val gear = Button(this).apply {
            text = "⚙"
            textSize = 20f
            setOnClickListener { showSettings() }
        }
        top.addView(gear, LinearLayout.LayoutParams(58, 58))
        root.addView(top)

        val core = TextView(this).apply {
            text = "◉"
            textSize = 74f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 10)
        }
        root.addView(core)

        status = TextView(this).apply {
            text = "SYSTEM ONLINE • READY"
            textSize = 14f
            gravity = Gravity.CENTER
        }
        root.addView(status)

        chat = TextView(this).apply {
            text = "JARVIS: Hello. Type a command or say “Hey JARVIS”."
            textSize = 15f
            setPadding(12, 18, 12, 12)
        }
        root.addView(chat)

        input = EditText(this).apply {
            hint = "Ask JARVIS anything…"
            singleLine = true
        }
        root.addView(input)

        val ask = Button(this).apply {
            text = "SEND TO JARVIS"
            setOnClickListener { handleCommand(input.text.toString()) }
        }
        root.addView(ask)

        val apiLabel = TextView(this).apply {
            text = "AI API KEY (saved only on this device)"
            textSize = 12f
            setPadding(0, 14, 0, 4)
        }
        root.addView(apiLabel)

        apiKey = EditText(this).apply {
            hint = "Paste your API key here"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", ""))
        }
        root.addView(apiKey)

        connect = Button(this).apply {
            text = "SAVE / CONNECT AI"
            setOnClickListener {
                prefs.edit().putString("api_key", apiKey.text.toString()).apply()
                status.text = if (apiKey.text.isNullOrBlank()) "AI KEY NOT SET" else "AI KEY SAVED • READY"
            }
        }
        root.addView(connect)

        val voice = Button(this).apply {
            text = "START BACKGROUND VOICE"
            setOnClickListener { startVoice() }
        }
        root.addView(voice)

        val stop = Button(this).apply {
            text = "STOP BACKGROUND VOICE"
            setOnClickListener { stopService(Intent(this@MainActivity, JarvisVoiceService::class.java)) }
        }
        root.addView(stop)

        val quickTitle = TextView(this).apply {
            text = "QUICK ACTIONS"
            textSize = 13f
            setPadding(0, 16, 0, 4)
        }
        root.addView(quickTitle)

        val quick = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val names = listOf("YouTube", "Web Search", "Music", "Weather", "Reminder")
            names.forEach { name ->
                val b = Button(this@MainActivity).apply {
                    text = name
                    textSize = 10f
                    setOnClickListener { quickAction(name) }
                }
                addView(b, LinearLayout.LayoutParams(0, 52, 1f))
            }
        }
        root.addView(quick)

        setContentView(root)
    }

    private fun applyTheme(name: String) {
        themeName = name
        val bg = when (name) {
            "LIGHT" -> Color.rgb(245,245,248)
            "IRON-MAN" -> Color.rgb(20,12,12)
            "SPIDER-MAN" -> Color.rgb(12,16,28)
            else -> Color.rgb(8,11,18)
        }
        val fg = if (name == "LIGHT") Color.rgb(25,25,30) else Color.WHITE
        root.setBackgroundColor(bg)
        setAllTextColor(root, fg)
    }

    private fun setAllTextColor(v: View, color: Int) {
        if (v is TextView) v.setTextColor(color)
        if (v is ViewGroup) for (i in 0 until v.childCount) setAllTextColor(v.getChildAt(i), color)
    }

    private fun showThemeMenu() {
        val themes = arrayOf("IRON-MAN", "DARK", "LIGHT", "SPIDER-MAN")
        AlertDialog.Builder(this)
            .setTitle("JARVIS THEME")
            .setItems(themes) { _, which ->
                val t = themes[which]
                prefs.edit().putString("theme", t).apply()
                applyTheme(t)
            }.show()
    }

    private fun showSettings() {
        AlertDialog.Builder(this)
            .setTitle("JARVIS SETTINGS")
            .setMessage("Theme: $themeName\n\nAI key is stored locally. Background voice uses Android SpeechRecognizer and may be limited by Android/phone battery restrictions.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun startVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, JarvisVoiceService::class.java))
        status.text = "BACKGROUND VOICE • LISTENING"
    }

    private fun quickAction(name: String) {
        when (name) {
            "YouTube" -> openUrl("https://www.youtube.com")
            "Web Search" -> openUrl("https://www.google.com/search?q=JARVIS")
            "Music" -> {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com"))
                startActivity(i)
            }
            "Weather" -> openUrl("https://www.google.com/search?q=weather+today")
            "Reminder" -> scheduleReminder("JARVIS reminder")
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim()
        if (command.isEmpty()) return
        chat.text = "YOU: $command\n\nJARVIS: Processing…"
        val lower = command.lowercase()

        when {
            lower.contains("open youtube") || lower == "youtube" -> {
                openUrl("https://www.youtube.com")
                chat.text = "YOU: $command\n\nJARVIS: Opening YouTube."
            }
            lower.startsWith("search ") || lower.contains("search web") -> {
                val q = command.replace(Regex("(?i)^search( web)?\\s*"), "").ifBlank { "JARVIS" }
                openUrl("https://www.google.com/search?q=" + Uri.encode(q))
                chat.text = "YOU: $command\n\nJARVIS: Searching the web."
            }
            lower.contains("weather") -> {
                openUrl("https://www.google.com/search?q=weather+today")
                chat.text = "YOU: $command\n\nJARVIS: Opening weather."
            }
            lower.contains("play music") || lower == "music" -> {
                openUrl("https://music.youtube.com")
                chat.text = "YOU: $command\n\nJARVIS: Opening music."
            }
            lower.contains("remind me") -> {
                scheduleReminder(command)
                chat.text = "YOU: $command\n\nJARVIS: Reminder scheduled for about 10 minutes from now."
            }
            else -> askAi(command)
        }
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "No suitable app found", Toast.LENGTH_SHORT).show() }
    }

    private fun scheduleReminder(text: String) {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("text", text)
        val pi = PendingIntent.getBroadcast(
            this, System.currentTimeMillis().toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 10 * 60 * 1000L, pi)
    }

    private fun askAi(question: String) {
        val key = prefs.getString("api_key", "") ?: ""
        if (key.isBlank()) {
            chat.text = "YOU: $question\n\nJARVIS: Add your AI API key first. Local commands such as YouTube, search, music, weather and reminders work without an AI key."
            return
        }

        executor.execute {
            val answer = callOpenAiResponsesApi(key, question)
            runOnUiThread {
                chat.text = "YOU: $question\n\nJARVIS: $answer"
            }
        }
    }

    private fun callOpenAiResponsesApi(key: String, question: String): String {
        return try {
            val url = URL("https://api.openai.com/v1/responses")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true

            val body = JSONObject()
                .put("model", "gpt-4.1-mini")
                .put("input", question)
                .toString()

            conn.outputStream.use { it.write(body.toByteArray()) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val response = stream.bufferedReader().use { it.readText() }

            if (conn.responseCode !in 200..299) {
                "AI request failed (${conn.responseCode}). Check the API key/model/account."
            } else {
                val json = JSONObject(response)
                extractResponseText(json)
            }
        } catch (e: Exception) {
            "I couldn't reach the AI service. Check your internet connection and API settings."
        }
    }

    private fun extractResponseText(json: JSONObject): String {
        val direct = json.optString("output_text", "")
        if (direct.isNotBlank()) return direct

        val output = json.optJSONArray("output") ?: return "AI returned no text."
        val parts = StringBuilder()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val c = content.optJSONObject(j) ?: continue
                val text = c.optString("text", "")
                if (text.isNotBlank()) parts.append(text)
            }
        }
        return parts.toString().ifBlank { "AI returned no readable text." }
    }
}
