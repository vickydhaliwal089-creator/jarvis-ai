package com.jarvis.assistant

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import androidx.core.app.NotificationCompat
import java.util.Locale

class JarvisVoiceService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private val channelId = "jarvis_voice"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS Voice")
            .setContentText("Listening for “Hey JARVIS”")
            .setOngoing(true)
            .build()
        startForeground(1001, notification)
        startRecognition()
    }

    private fun startRecognition() {
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf()
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onError(error: Int) {
                listening = false
                Handler(Looper.getMainLooper()).postDelayed({ startRecognition() }, 900)
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
                val heard = matches.firstOrNull() ?: return
                val lower = heard.lowercase(Locale.getDefault())
                if (lower.contains("hey jarvis") || lower.contains("jarvis")) {
                    handleVoiceCommand(heard)
                }
                Handler(Looper.getMainLooper()).postDelayed({ startRecognition() }, 500)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) {}
    }

    private fun handleVoiceCommand(spoken: String) {
        val command = spoken.replace(Regex("(?i).*?hey jarvis\\s*"), "")
            .replace(Regex("(?i)^jarvis\\s*"), "").trim()

        val lower = command.lowercase()
        val i = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("voice_command", command)
        }

        // Android may block launching an Activity from the background.
        // We still notify the user so the command can be continued safely.
        val n = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS heard you")
            .setContentText(if (command.isBlank()) "Say a command after JARVIS." else command)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(1002, n)

        // Simple background-safe actions that do not require opening an Activity.
        if (lower.contains("stop voice")) stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(channelId, "JARVIS Voice", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
