# JARVIS V3 Complete

Included:
- New futuristic JARVIS interface
- 3-dot theme menu: Iron-Man, Dark, Light, Spider-Man
- Local API-key storage (not logged)
- AI question answering through the OpenAI Responses API
- YouTube, web search, music and weather quick actions
- Reminder scheduling with Android notifications
- Background voice foundation with “Hey JARVIS” / “JARVIS” detection
- Correct AndroidManifest permissions, including ACCESS_NETWORK_STATE inside <manifest>
- No Gradle wrapper required; GitHub Actions can use installed Gradle 8.7

Important:
- Put your own API key into the app. Never commit an API key to GitHub.
- The background voice feature uses Android SpeechRecognizer, not a dedicated low-power wake-word engine. Android/phone battery and background-activity restrictions can affect it.
- When JARVIS hears a command while the app is in the background, Android may prevent it from directly opening another app. A notification is shown so the command can be continued safely.
- The AI endpoint/model is configured in MainActivity.kt and requires a valid OpenAI API key and account access.


Build compatibility: Android Gradle Plugin 8.6.1 is paired with Gradle 8.7 used by the existing GitHub Actions workflow.
